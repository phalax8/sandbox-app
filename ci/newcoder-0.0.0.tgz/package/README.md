# newcoder

AI review of git changes, guided by specifications (SDD). Local and open source (Apache-2.0).

```bash
npm install -g newcoder
newcoder init                    # prepare the repository (AGENTS.md, config, skills)
newcoder review                  # review your uncommitted changes
newcoder review feature/login    # review a branch against main
newcoder spec new payments --describe "Card payments with 3-D Secure"
```

- Uses the AI subscriptions you already have: **Claude Code** or **GitHub Copilot CLI**.
- Reviews against the spec: EARS requirements, design and tasks in `.newcoder/specs/`.
- Detects typical AI-agent mistakes: suppressed checks, weakened tests, invented packages, duplicated code.
- The review agent only reads: it never changes your code or infrastructure.

Interface in Spanish (default), English and Basque: `--lang es|en|eu` or `NEWCODER_LANG`.

More: https://github.com/phalax8/newcoder
