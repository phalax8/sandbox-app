export interface Database {
  query<T>(sql: string, params?: readonly unknown[]): Promise<T[]>;
}

export declare const db: Database;
