import { db } from './db.js';

export interface User {
  id: string;
  email: string;
}

/** Finds a user by id. */
export async function findUser(id: string): Promise<User | undefined> {
  const rows = await db.query<User>('SELECT id, email FROM users WHERE id = $1', [id]);
  return rows[0];
}
