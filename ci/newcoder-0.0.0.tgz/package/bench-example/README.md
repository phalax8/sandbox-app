# Example bench set

Four small TypeScript cases with seeded faults, for `newcoder bench --example`:

| Case | Fault |
| --- | --- |
| `sql-injection` | The query concatenates the user id (`security`). |
| `missing-error-check` | The HTTP status of a payment is no longer checked (`bug`). |
| `hardcoded-secret` | A connection string with its password in the code (`security`). |
| `spec-gap` | The change implements R1.1 of its spec but not R1.2 (`spec-gap`). |

Each case has its code in `base/`, the change to review in `change.patch` and the expected faults in `case.yaml`. The faults are fake: nothing here is a real credential or service.
