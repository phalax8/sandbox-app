/** Database connection settings. */
export const database = {
  url: process.env.DATABASE_URL ?? '',
  poolSize: 10,
};
