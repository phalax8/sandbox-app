export interface User {
  email: string;
  passwordHash: string;
}

export declare function findByEmail(email: string): Promise<User | undefined>;
export declare function verify(password: string, hash: string): Promise<boolean>;
export declare function newToken(user: User): string;
