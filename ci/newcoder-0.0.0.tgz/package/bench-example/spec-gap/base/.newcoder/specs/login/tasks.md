---
status: approved
---

# Tasks: login

- [ ] **T1** Sign in with email and password · _R1_
