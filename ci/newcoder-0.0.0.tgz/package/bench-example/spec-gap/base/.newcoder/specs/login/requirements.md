---
status: approved
---

# Requirements: login

## R1. Sign in

**Story:** As a user I want to sign in with my email and password.

- **R1.1** WHEN the user sends a correct email and password, THE SYSTEM SHALL return a session token.
- **R1.2** IF the password is not correct, THEN THE SYSTEM SHALL reject the attempt with a 401 error and return no token.
