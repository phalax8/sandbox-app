export interface Charge {
  id: string;
  amount: number;
}

/** Charges a card through the payments API. */
export async function charge(token: string, amount: number): Promise<Charge> {
  const response = await fetch('https://payments.example.com/charges', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ token, amount }),
  });
  if (!response.ok) {
    throw new Error(`charge failed: ${response.status}`);
  }
  return (await response.json()) as Charge;
}
